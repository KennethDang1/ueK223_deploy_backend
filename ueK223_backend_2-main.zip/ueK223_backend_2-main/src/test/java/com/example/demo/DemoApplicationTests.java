package com.example.demo;

import org.junit.jupiter.api.Test;

class DemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
