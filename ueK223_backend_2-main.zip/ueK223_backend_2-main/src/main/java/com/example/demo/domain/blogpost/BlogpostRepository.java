package com.example.demo.domain.blogpost;

import com.example.demo.core.generic.AbstractRepository;

public interface BlogpostRepository extends AbstractRepository<Blogpost> {
}
